INSERT INTO plans (id, limit_per_hour, name) VALUES ('631d899b-baf5-46ca-891f-0b36483ba26f', 20, 'FREE');
INSERT INTO plans (id, limit_per_hour, name) VALUES ('519b0e8f-911c-4a5d-8b3f-eaac88c3d5fb', 40, 'BUSINESS');
INSERT INTO plans (id, limit_per_hour, name) VALUES ('a1654488-2d82-497b-8c0b-ed8b97d4a3e2', 100, 'PROFESSIONAL');