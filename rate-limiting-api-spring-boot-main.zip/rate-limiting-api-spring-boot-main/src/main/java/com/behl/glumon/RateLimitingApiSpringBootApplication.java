package com.behl.glumon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateLimitingApiSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RateLimitingApiSpringBootApplication.class, args);
	}

}
